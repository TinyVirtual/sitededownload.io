var n, m;

scanf("%d %d","m","n");

var changes = 0;

var plate = Array(m);
for(var i = 0; i < plate.length; i++){
  plate[i] = Array(n);
}

for(var y = 0; y < m; y++){
  for(var x = 0; x < n; x++){
     scanf("%d","plate[y][x]");
  }
}


var sums = Array(m);
for(var i = 0; i < sums.length; i++){
  sums[i] = Array(n);
   for(var j = 0; j < n; j++){
      sums[i][j] = 1;
   }
}
 

 for(var y = 0; y < plate.length; y++){
  for(var x = 0; x < plate[y].length; x++){
     if(plate[y][x] % 2 < 1){
        sums[y][x] = 0;
     }
  }
 }

function check(){
for(var y = 0; y < plate.length; y++){
   for(var x = 0; x < plate[y].length; x++){
      var diffs = 0;
      for(_y = -1; _y <= 1; _y+=2){
         if(!(y+_y <= -1 || y+_y >= plate.length)){
         diffs += (sums[y+_y][x] ==  sums[y][x])?1:0;
         }
      }
      for(_x = -1; _x <= 1; _x+=2){
         if(!(x+_x <= -1 || x+_x >= plate.length)){
         diffs += (sums[y][x+_x] == sums[y][x])?1:0;
         }
      }
      if(diffs > 1){
         sums[y][x] = (sums[y][x] + 1) % 2;
         plate[y][x]++;
         changes++;
      }
   }
}
}
for(var i = 0; i < 10; i++){
check();
}

//console.log(sums);
printf("%d\n",changes);
       
for(var y = 0; y < plate.length; y++){
  printf("%s\n",plate[y].join(" "));
}