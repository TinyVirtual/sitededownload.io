var p;
scanf("%d","p");

var par = {
   l: [],
   a: [],
   b: []
};

for(var i = 0; i < p; i++){
   scanf("%d %d %d\n","par.l[i]","par.a[i]","par.b[i]");
}

var res = Array(p);
for(var i = 0; i < res.length; i++){
   res[i] = 0;
}

for(var c = 0; c < p; c++){
   var values = [par.a[c],0];
   
   while(values[0] <= par.l[c]){
      res[c]++;
      values[1]+=values[0];
      values[0]++;
      if (values[1] >= par.l[c] || values[0] > par.b[c]){
         break;
      }
   }
}

printf("%s",res.join("\n"));