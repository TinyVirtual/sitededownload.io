var p, c;
var ptime = [];
var ctime = [];

scanf("%d","p");
for(var i = 0; i < p; i++){
   scanf("%d","ptime[i]");
}
scanf("\n%d","c");
for(var i = 0; i < c; i++){
	scanf("%d","ctime[i]");
}

var output = [[0,0]];

var goals = [0,0];
var timeCursor = 0
while(timeCursor <= Math.max(...ptime,...ctime)){      
   if(ptime.find((a)=>(a==timeCursor))){
	goals[0] += 1;
    output.push([...goals])
   } else if(ctime.find((a)=>(a==timeCursor))){
    goals[1] += 1;
    output.push([...goals]) 
   }
   timeCursor += 1;
}

for(var i of output){
  printf("%d %d\n",i[0],i[1]); 
}